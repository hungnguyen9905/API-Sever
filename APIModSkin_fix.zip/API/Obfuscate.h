#ifndef ENHANCED_MACRO_H
#define ENHANCED_MACRO_H

#include <stdint.h>
#include <stddef.h>
#include <cstdio>
#include <cstdlib>

#if defined(__clang__) || defined(__GNUC__)
#define ALWAYS_INLINE __attribute__((always_inline)) inline
#elif defined(_MSC_VER)
#define ALWAYS_INLINE __forceinline
#else
#define ALWAYS_INLINE inline
#endif

// Seed generation using current compile time
constexpr int seedToInt(char c) { return c - '0'; }
constexpr int compileTimeSeed = seedToInt(__TIME__[7]) +
                                seedToInt(__TIME__[6]) * 10 +
                                seedToInt(__TIME__[4]) * 60 +
                                seedToInt(__TIME__[3]) * 600 +
                                seedToInt(__TIME__[1]) * 3600 +
                                seedToInt(__TIME__[0]) * 36000;

// Compile-time pseudorandom number generator
constexpr uintptr_t fastCompileTimeRandom(uintptr_t seed, uintptr_t Id)
{
    return (seed + 1664525 * Id) & 0xFFFFFFFF;
}

// Thiết lập giá trị khởi tạo cho hằng số
constexpr uintptr_t initialRandomSeed = fastCompileTimeRandom(1013904223, compileTimeSeed);

// Macros to generate compile-time random values
#define COMPILE_TIME_RANDOM(Min, Max) (Min + (COMPILE_TIME_RAND() % (Max - Min + 1)))
#define COMPILE_TIME_RAND()           (fastCompileTimeRandom(initialRandomSeed, __COUNTER__ + 1))

// Template for list of indices
template <uintptr_t...> struct CompileTimeIndexList {};
template <typename IndexList, uintptr_t Right> struct CompileTimeAppend;
template <uintptr_t... Left, uintptr_t Right> struct CompileTimeAppend<CompileTimeIndexList<Left...>, Right> { typedef CompileTimeIndexList<Left..., Right> Result; };
template <uintptr_t N> struct CompileTimeIndexes { typedef typename CompileTimeAppend<typename CompileTimeIndexes<N - 1>::Result, N - 1>::Result Result; };
template <> struct CompileTimeIndexes<0> { typedef CompileTimeIndexList<> Result; };

// Encryption key and function for compile-time string encryption
constexpr char compileTimeEncryptCharKey = static_cast<char>(COMPILE_TIME_RANDOM(0, 0xFF));
constexpr char ALWAYS_INLINE compileTimeEncryptChar(const char Ch, uintptr_t Idx) { return Ch ^ (compileTimeEncryptCharKey + Idx); }

// Template for encrypted string at compile-time
template <typename IndexList> struct CompileTimeEncryptedString;
template <uintptr_t... Idx> struct CompileTimeEncryptedString<CompileTimeIndexList<Idx...> >
{
    char Value[sizeof...(Idx) + 1];

    constexpr ALWAYS_INLINE CompileTimeEncryptedString(const char* const Str)
        : Value{ compileTimeEncryptChar(Str[Idx], Idx)..., '\0' } {}

    inline const char* decrypt() const
    {
        for (uintptr_t t = 0; t < sizeof...(Idx); t++)
        {
            const_cast<char&>(this->Value[t]) = this->Value[t] ^ (compileTimeEncryptCharKey + t);
        }
        return this->Value;
    }
};

// Macro to encrypt string at compile-time
#define ENCRYPT(Str) (CompileTimeEncryptedString<CompileTimeIndexes<sizeof(Str) - 1>::Result>(Str).decrypt())

#ifdef __APPLE__
#define NSSENCRYPT(Str) @(ENCRYPT(Str))
#endif

// Compile-time offset string encryption macro, converts back to uint64_t.
#define ENCRYPTOFFSET(Str) strtoull(ENCRYPT(Str), NULL, 0)

// Compile-time hex string encryption macro, does same as ENCRYPT, but the naming is just more clear.
#define ENCRYPTHEX(Str) ENCRYPT(Str)

// Compile-time dump string encryption macro
#define ENCRYPTDUMP(Str) printf("%s", ENCRYPT(Str))

#endif // ENHANCED_MACRO_H
