#import <Foundation/Foundation.h>
#import "API/API.h"
#import "API/Obfuscate.h"
#import "SSZipArchive/SSZipArchive.h"

@interface Menu : NSObject
@end

@implementation Menu

+ (void)load {
    // Thiết lập token cho API từ lớp Menu với bảo vệ
    API *APIClient = [API sharedClient];
    
    // Thiết lập token
     [APIClient setToken:NSSENCRYPT("cylight")];
    
    
    // Kiểm tra token trước khi gọi phương thức load
    dispatch_async(dispatch_get_main_queue(), ^{
        NSLog(@"Active");
        NSLog(@"APIData - Key: %@", [APIClient getKey]);
        NSLog(@"APIData - UDID: %@", [APIClient getUDID]);
        NSLog(@"APIData - Expiry date: %@", [APIClient getExpiryDate]);
        NSLog(@"APIData - Device model: %@", [APIClient getDeviceModel]);
    });
}

@end
