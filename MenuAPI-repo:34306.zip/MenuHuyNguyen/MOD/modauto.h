#import <mach/mach.h>
#import <sys/sysctl.h>
#import <sys/param.h>
#import <sys/mount.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <SafariServices/SafariServices.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <Photos/Photos.h>
#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "SSZipArchive/SSZipArchive.h"

#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width

@interface modauto : NSObject <UIGestureRecognizerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>

+ (instancetype)sharemodauto;

- (void)someMethodToShowLinkSelection;

@end
