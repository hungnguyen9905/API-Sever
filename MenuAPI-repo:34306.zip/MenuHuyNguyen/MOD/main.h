#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface main : NSObject <UIDocumentPickerDelegate>

+ (instancetype)sharemain;

- (void)openFilePicker;
@end