//Yuan Nan
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AnhNamVaDanHarem : UIView

+ (instancetype)BanTumLum;
- (void)AnBaToCom;

@end

NS_ASSUME_NONNULL_END
