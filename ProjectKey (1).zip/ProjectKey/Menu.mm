#import <Foundation/Foundation.h>
#import "API/API.h"
#import "API/Obfuscate.h" // sử dụng đúng file mã hoá đi kèm

@interface Menu : NSObject
@end

@implementation Menu

+ (void)load {
    // Gọi Client từ lớp API để khởi động ứng dụng
    API *APIClient = [API sharedClient];
    
    // Thiết lập token 
     [APIClient setToken:NSSENCRYPT("cylight")];
    // thông số cần lấy dữ liệu nếu cần
    dispatch_async(dispatch_get_main_queue(), ^{
        NSLog(@"Active");
        NSLog(@"APIData - Key: %@", [APIClient getKey]);
        NSLog(@"APIData - UDID: %@", [APIClient getUDID]);
        NSLog(@"APIData - Expiry date: %@", [APIClient getExpiryDate]);
        NSLog(@"APIData - Device model: %@", [APIClient getDeviceModel]);
    });
}

@end
